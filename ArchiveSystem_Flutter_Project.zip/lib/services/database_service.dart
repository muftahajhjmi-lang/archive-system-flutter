import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final folder = await getApplicationDocumentsDirectory();
    await Directory(folder.path).create(recursive: true);
    final dbPath = p.join(folder.path, 'archive_system.db');
    _db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_number TEXT,
            employee_number TEXT,
            full_name TEXT,
            mother_name TEXT,
            nationality TEXT,
            identity_number TEXT,
            entry_date TEXT,
            exit_date TEXT,
            notes TEXT
          )
        ''');
      },
    );
    return _db!;
  }

  Future<List<Map<String, Object?>>> getRecords({String query = ''}) async {
    final db = await database;
    if (query.trim().isEmpty) {
      return db.query('records', orderBy: 'id DESC');
    }
    return db.query(
      'records',
      where: 'full_name LIKE ? OR employee_number LIKE ? OR identity_number LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'id DESC',
    );
  }

  Future<void> insertRecord(Map<String, Object?> values) async {
    final db = await database;
    await db.insert('records', values);
  }

  Future<void> deleteRecord(int id) async {
    final db = await database;
    await db.delete('records', where: 'id = ?', whereArgs: [id]);
  }
}
