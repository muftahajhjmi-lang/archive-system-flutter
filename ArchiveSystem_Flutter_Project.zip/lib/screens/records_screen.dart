import 'package:flutter/material.dart';
import '../services/database_service.dart';

class RecordsScreen extends StatefulWidget {
  const RecordsScreen({super.key});

  @override
  State<RecordsScreen> createState() => _RecordsScreenState();
}

class _RecordsScreenState extends State<RecordsScreen> {
  final search = TextEditingController();
  Future<List<Map<String, Object?>>>? recordsFuture;

  @override
  void initState() {
    super.initState();
    recordsFuture = DatabaseService.instance.getRecords();
  }

  void refresh() {
    setState(() => recordsFuture = DatabaseService.instance.getRecords(query: search.text));
  }

  Future<void> addRecord() async {
    final name = TextEditingController();
    final employee = TextEditingController();
    final identity = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إضافة سجل'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم الكامل')),
            TextField(controller: employee, decoration: const InputDecoration(labelText: 'الرقم الوظيفي')),
            TextField(controller: identity, decoration: const InputDecoration(labelText: 'رقم الهوية')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      await DatabaseService.instance.insertRecord({
        'full_name': name.text.trim(),
        'employee_number': employee.text.trim(),
        'identity_number': identity.text.trim(),
      });
      refresh();
    }
  }

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          TextField(
            controller: search,
            onChanged: (_) => refresh(),
            decoration: const InputDecoration(
              labelText: 'ابحث بالاسم أو الرقم الوظيفي أو الهوية',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.icon(
              onPressed: addRecord,
              icon: const Icon(Icons.add),
              label: const Text('إضافة سجل'),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: FutureBuilder(
              future: recordsFuture,
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final rows = snapshot.data!;
                if (rows.isEmpty) return const Center(child: Text('لا توجد سجلات'));
                return ListView.builder(
                  itemCount: rows.length,
                  itemBuilder: (context, i) {
                    final row = rows[i];
                    return Card(
                      child: ListTile(
                        title: Text((row['full_name'] ?? '').toString()),
                        subtitle: Text('الرقم الوظيفي: ${row['employee_number'] ?? ''}   الهوية: ${row['identity_number'] ?? ''}'),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async {
                            await DatabaseService.instance.deleteRecord(row['id'] as int);
                            refresh();
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
