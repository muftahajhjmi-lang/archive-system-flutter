import 'package:flutter/material.dart';
import '../services/database_service.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: DatabaseService.instance.getRecords(),
      builder: (context, snapshot) {
        final count = snapshot.data?.length ?? 0;
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.archive_outlined, size: 76),
                const SizedBox(height: 18),
                const Text('منظومة إدارة المحفوظات', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text('عدد السجلات: $count', style: const TextStyle(fontSize: 18)),
                const SizedBox(height: 8),
                const Text('قاعدة بيانات محلية جديدة وفارغة'),
              ],
            ),
          ),
        );
      },
    );
  }
}
