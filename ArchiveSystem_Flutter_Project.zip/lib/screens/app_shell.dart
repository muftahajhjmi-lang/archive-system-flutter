import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'records_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  final pages = const [HomeScreen(), RecordsScreen()];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('وحدة المحفوظات والتوثيق بشؤون النزلاء'),
          centerTitle: true,
          backgroundColor: Theme.of(context).colorScheme.surfaceContainer,
          bottom: const PreferredSize(
            preferredSize: Size.fromHeight(30),
            child: Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text('جهاز الشرطة القضائية'),
            ),
          ),
        ),
        body: SafeArea(child: pages[index]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.table_view_outlined), label: 'السجلات'),
          ],
        ),
      ),
    );
  }
}
