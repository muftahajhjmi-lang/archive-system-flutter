# مشروع وحدة المحفوظات والتوثيق بشؤون النزلاء

مشروع Flutter أولي مستقل، بقاعدة بيانات محلية جديدة وفارغة، وواجهة عربية RTL.

## المتطلبات
- Flutter SDK حديث
- Android SDK لبناء APK
- Windows 10 مع Visual Studio (Desktop development with C++) لبناء نسخة Windows

## إنشاء هيكل المشروع
```bash
flutter create --platforms=android,windows archive_system
```

انسخ محتويات هذا الأرشيف إلى مجلد `archive_system` مع استبدال الملفات عند الطلب، ثم نفّذ:
```bash
flutter pub get
flutter run
```

لبناء APK:
```bash
flutter build apk --release
```
ملف APK الناتج يوجد عادة في:
`build/app/outputs/flutter-apk/app-release.apk`

لبناء Windows:
```bash
flutter build windows --release
```

## ملاحظة
هذه نسخة تأسيسية أولية وليست APK جاهزاً. لم يتم تنفيذ أو اختبار البناء في هذه الحزمة.
